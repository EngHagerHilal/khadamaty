module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DB: "rafeegtest",
    dialect: "mysql"
};
  