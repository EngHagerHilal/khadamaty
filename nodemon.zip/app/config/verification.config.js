module.exports = {

    customerId : "DB3C0DE1-4B17-4C07-ADB8-8D365F1C49CE" ,
    apiKey : "FVDr7PFK265+AoJu/tyunnxIBlgQmA3xWW+ILyINnEMPhBJoNGl3fyBdOAGU9gZf/nDx1dTZYr8YTB6dl+iJsw==" ,
    rest_endpoint : "https://rest-api.telesign.com" 
};