const db = require("../models");
const Service = db.service;
const Op = db.Sequelize.Op;
const Subservice = db.subservice;


// Add services
exports.addService = (req, res) => {
Service.create(req.body).then((service)=> {
    if ( req.body.subservices) { 
    req.body.subservices.forEach(function(value){
        Subservice.findAll({ where: { title : value.title} }).then( data => {
            if (data.length == 0) {
              Subservice.create({title : value.title , serviceId : service.id}).then(res.send({msg : "set subservices"})).catch(err => res.send({msg : err}));
            }
        });
    });    
    res.json("Service added Successfully")
  }
})
};

/*
// Add subservices
exports.addSubservice = (req, res) => {
    Subservice.create({title : req.body.title }).then(()=> res.send({msg : "Subservice added successfully!"})).catch(err => res.send({msg : err.message}))
};
*/  


// Retrieve all Services from the database.
exports.getAllServices = (req, res) => {
    Service.findAll()
    .then(data => {
      res.send({data : data});
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Services."
      });
    });
};


 //Get All subservices of a service  
exports.findOne = (req, res) => {
  
};

// Update a Tutorial by the id in the request
exports.update = (req, res) => {
  
};

// Delete a Tutorial with the specified id in the request
exports.delete = (req, res) => {
  console.log(req.params.id)
  Service.destroy({where : {id:req.params.id}}).then(()=> res.send({msg : "service deleted successfully"})).catch(err => res.send({msg : err.message}) );
};

// Delete all Tutorials from the database.
exports.deleteAll = (req, res) => {
  
};

// Find all published Tutorials
exports.findAllPublished = (req, res) => {
  
};

