module.exports = (sequelize, Sequelize) => {
    const Shop = sequelize.define("shops", {
      shopid: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
      },
      name : {
        type: Sequelize.STRING ,
        allowNull: false,
        unique : true
      },
      ownername : {
        type : Sequelize.STRING 
      },
      location : {
        type : Sequelize.STRING
      },
      city : {
        type : Sequelize.STRING
      },
      rate : {
         type : Sequelize.FLOAT 
      },
      verified : {
         type : Sequelize.BOOLEAN ,
         defaultValue : false 
      },
      description : {
        type: Sequelize.STRING ,
        allowNull: false
      }
    });
    return Shop ;
};