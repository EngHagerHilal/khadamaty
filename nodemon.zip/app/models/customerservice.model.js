module.exports = (sequelize, Sequelize) => {
    const CustomerService = sequelize.define("customerservices", {
     
    });
    return CustomerService;
};