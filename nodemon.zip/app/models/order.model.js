module.exports = (sequelize, Sequelize) => {
    const {  DataTypes } = require('sequelize');
    const Order = sequelize.define("orders", {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    location :{
       type : Sequelize.STRING
    },
    status : {
        type : Sequelize.ENUM , 
        values : ['Completed' , 'InProgress' , 'Accepted' , 'Rejected' ]
    },
    description : {
        type : Sequelize.STRING
    },
      city : {
        type : Sequelize.STRING
      }
    }
); 
    return Order;
};
  