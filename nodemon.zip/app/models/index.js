const dbConfig = require("../config/db.config.js");
const Sequelize = require("sequelize");
const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
  host: dbConfig.HOST,
  dialect: dbConfig.dialect,
  operatorsAliases: false
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.user = require("../models/user.model.js")(sequelize, Sequelize);
db.role = require("../models/role.model.js")(sequelize, Sequelize);
db.admin = require("../models/admin.model.js")(sequelize, Sequelize);
db.customerservice = require("../models/customerservice.model.js")(sequelize, Sequelize);
db.customer = require("../models/customer.model.js")(sequelize, Sequelize);
db.shop = require("../models/shop.model.js")(sequelize, Sequelize);
db.offer = require("../models/offer.model.js")(sequelize, Sequelize);
db.order = require("../models/order.model.js")(sequelize, Sequelize);
db.service = require("./service.model.js")(sequelize, Sequelize);
db.subservice = require("./subservice.model.js")(sequelize, Sequelize);

/*
db.role.belongsToMany(db.user, {
  through: "user_roles",
  foreignKey: "db.role.name"

});
*/

db.shop.belongsTo(db.user);

db.admin.belongsTo(db.user);

db.customerservice.belongsTo(db.user);

db.customer.belongsTo(db.user);

db.subservice.belongsTo(db.service );


db.shop.belongsTo( db.service , {
through : db.shop
});

db.order.belongsTo(db.user);

db.order.belongsTo(db.shop);

db.order.belongsTo(db.service);


db.order.belongsToMany(db.subservice , {
  through: 'orders_subservices',
});


/*
db.admin.hasMany(db.customerservice, {
  as : 'Workers',
  foreignKey : 'db.admin.id'
});

db.service.hasMany(db.subservice , {
foreignKey :  "db.service.id" ,
otherKey : "db.service.title"
});

db.shop.belongsToMany(db.service , { 
  through : "Services_Shop" ,
  foreignKey : "db.service.id" ,
  otherKey : "db.shop.id"
});
*/
/*
db.service.hasMany(db.shop , {
  
  as : 'shops'
});
*/
/*
db.customer.hasMany(db.order , {
  otherKey : "db.customer.username" ,
  foreignKey : "db.user.id"
});

db.shop.hasMany ( db.offer , {
  foreignKey : "db.user.id" ,
  otherKey : "db.shop.shopname"
});

db.order.hasOne ( db.service , {
  foreignKey : "db.service.id"
});
*/
db.ROLES = ["admin", "customerservice", "customer" , "shop"];


module.exports = db;
