


module.exports = (sequelize, Sequelize) => {
  const DataTypes  = require('sequelize');
    const Service = sequelize.define("services", {
      title: {
        type: Sequelize.STRING ,
        unique : true

      },
      id : {
        type: Sequelize.INTEGER ,
        primaryKey : true ,
        autoIncrement : true
      }
    }
  );
    return Service;
  };
  