module.exports = (sequelize, Sequelize) => {
    const Admin = sequelize.define("admins", {
        
    });
    return Admin;
};