module.exports = (sequelize, Sequelize) => {
    const Customer = sequelize.define("customers", {
      name : {
        type: Sequelize.STRING ,
        allowNull: false,
      },
      location : {
          type : Sequelize.STRING
      } ,
      rate : {
          type : Sequelize.FLOAT 
      },
      city : {
        type : Sequelize.STRING
      }
    });
    return Customer;
};
