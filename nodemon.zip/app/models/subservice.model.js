module.exports = (sequelize, Sequelize) => {
    const Subservice = sequelize.define("subservices", {
    title: {
        type: Sequelize.STRING  ,
        primarykey : true ,
        unique : true
      }
    });
    return Subservice;
};