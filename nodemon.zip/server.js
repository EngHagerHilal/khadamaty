const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
var bcrypt = require("bcryptjs");
const db = require("./app/models");
const Role = db.role;
const User = db.user;
const Admin = db.admin;
const app = express();


const readline = require('readline');
var TeleSignSDK = require('telesignsdk');
//const customerId = "DB3C0DE1-4B17-4C07-ADB8-8D365F1C49CE";
//const apiKey = "FVDr7PFK265+AoJu/tyunnxIBlgQmA3xWW+ILyINnEMPhBJoNGl3fyBdOAGU9gZf/nDx1dTZYr8YTB6dl+iJsw==";

//const rest_endpoint = "https://rest-api.telesign.com";
//const timeout = 10*1000; // 10 secs
/*
const client = new TeleSignSDK( customerId,
    apiKey,
    rest_endpoint,
    timeout // optional
    // userAgent
);

const phoneNumber = "2001018906164";
const messageType = "ARN";
const verifyCode = "32658";
const message = "Your code is " + verifyCode;
*/
//console.log("## MessagingClient.message ##");
/*
function messageCallback(error, responseBody) {
      if (error === null) {
          console.log(`Messaging response for messaging phone number: ${phoneNumber}` +
              ` => code: ${responseBody['status']['code']}` +
              `, description: ${responseBody['status']['description']}`);
          prompt('Enter the verification code received:\n', function (input) {
              if (input === verifyCode) {
                  console.log('Your code is correct.');
              } else {
                console.log('Your code is incorrect. input: ' + input + ", code: " + verifyCode);
              }
              process.exit();
          });
      } else {
          console.error("Unable to send message. " + error);
      }
};

client.sms.message(messageCallback, phoneNumber, message, messageType);

function prompt(question, callback) {
      const stdin = process.stdin,
          stdout = process.stdout;

      stdin.resume();
      stdout.write(question);

      stdin.once('data', function (data) {
          callback(data.toString().trim());
      });
}
*/

/*
var corsOptions = {
  origin: "http://127.0.0.1:3000"
};
*/
app.use(cors());

// parse requests of content-type - application/json
app.use(bodyParser.json());

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Let's Start Our amazing app" });
});


// routes
require('./app/routes/auth.routes')(app);
require('./app/routes/user.routes')(app);
require('./app/routes/service.routes')(app);
require('./app/routes/order.routes')(app);


/*
db.sequelize.sync({ force: true }).then(() => {
    console.log("Drop and re-sync db.");
  });

*/
db
  .sequelize
  .query('SET FOREIGN_KEY_CHECKS = 0', {raw: true})
  .then(async function() {
  //await db.sequelize.sync({force: true})
   //return await initial();
});  


async function initial() {
    User.create({
      email : "admin@admin.com" ,
      username : "admin" , 
      password: bcrypt.hashSync("admin", 8) ,
      role : "admin" ,
      phone : "966506486374"
      }).then(user => {
        Admin.create(user)
      })
};

// set port, listen for requests
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
